/* tslint:disable */
/* eslint-disable */

/**
 * Parse all `<f-template>` elements from an HTML string.
 * Returns a JSON array of template metadata objects,
 * one per `<f-template>` element found. `name` is `null` when the element has
 * no `name` attribute.
 */
export function parse_f_templates(html: string): string;

/**
 * Render a FAST HTML template with an optional JSON state string.
 * Omitted state is treated as an empty object.
 * Returns the rendered HTML or throws a JavaScript error.
 */
export function render(entry: string, state?: string | null): string;

/**
 * Render the top-level **entry HTML** with custom element templates and an optional JSON state string.
 * Omitted state is treated as an empty object.
 * Custom elements found at the root level of `entry` build child state from the full root
 * state with HTML attributes overlaid on top. For `{{binding}}` attributes on root custom
 * elements, primitive results (`string`, `number`, and `bool`) are preserved in the rendered
 * output, while missing and non-primitive values (`array`, `object`, `null`) are stripped.
 *
 * `templates_json` is a JSON object mapping element names to their HTML template strings,
 * e.g. `{"my-button": "<template>...</template>"}`, or template metadata objects.
 * `attribute_name_strategy` controls attribute-to-property mapping: `"camelCase"` (default)
 * or `"none"`. Pass an empty string for the default.
 * Returns the rendered HTML or throws a JavaScript error.
 */
export function render_entry_with_templates(entry: string, templates_json: string, state?: string | null, attribute_name_strategy?: string | null): string;

/**
 * Render a FAST HTML template with custom element templates and an optional JSON state string.
 * Omitted state is treated as an empty object.
 *
 * This preserves the original non-entry rendering semantics for this export.
 * Use `render_entry_with_templates` for top-level entry HTML rendering.
 *
 * `templates_json` is a JSON object mapping element names to their HTML template strings,
 * e.g. `{"my-button": "<template>...</template>"}`, or template metadata objects.
 * `attribute_name_strategy` controls attribute-to-property mapping: `"camelCase"` (default)
 * or `"none"`. Pass an empty string for the default.
 * Returns the rendered HTML or throws a JavaScript error.
 */
export function render_with_templates(entry: string, templates_json: string, state?: string | null, attribute_name_strategy?: string | null): string;
